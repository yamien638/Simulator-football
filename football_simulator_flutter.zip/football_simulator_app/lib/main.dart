
import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'dart:convert';
import 'simulator.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Simulator Sepak Bola',
      theme: ThemeData.dark(),
      home: TerminalPage(),
    );
  }
}

class TerminalPage extends StatefulWidget {
  @override
  _TerminalPageState createState() => _TerminalPageState();
}

class _TerminalPageState extends State<TerminalPage> {
  final _controller = TextEditingController();
  final List<String> _output = [];
  Simulator? _sim;

  @override
  void initState() {
    super.initState();
    _loadTeams();
  }

  Future<void> _loadTeams() async {
    String csv = await rootBundle.loadString('assets/players_import.csv');
    Map<String, List<Player>> squads = {};
    LineSplitter.split(csv).skip(1).forEach((line) {
      var parts = line.split(',');
      if(parts.length < 3) return;
      String country = parts[0];
      String name = parts[1];
      double rating = double.tryParse(parts[2]) ?? 60;
      squads.putIfAbsent(country, () => []).add(Player(name, rating));
    });
    Map<String, Team> teams = { for (var e in squads.entries) e.key : Team(e.key, e.value)};
    setState(() {
      _sim = Simulator(teams);
      _output.add("Simulator siap! Ketik 'bantuan' untuk daftar perintah.");
    });
  }

  void _processCommand(String cmd) {
    if(_sim == null) return;
    String res;
    var tokens = cmd.trim().split(RegExp(r'\s+'));
    if(tokens.isEmpty) return;
    switch(tokens[0].toLowerCase()) {
      case 'main':
        if(tokens.length<3){ res = "Gunakan: main <NegaraA> <NegaraB>"; } 
        else { res = _sim!.play(tokens[1], tokens[2]); }
        break;
      case 'peringkat':
        res = _sim!.ranking();
        break;
      case 'keluar':
        res = "Keluar aplikasi.";
        break;
      case 'bantuan':
        res = "Perintah:\n- main <NegaraA> <NegaraB> : Simulasi pertandingan\n- peringkat : Lihat ranking\n- keluar : Tutup aplikasi";
        break;
      default:
        res = "Perintah tidak dikenal. Ketik 'bantuan'.";
    }
    setState(() {
      _output.add('> $cmd');
      _output.add(res);
      _controller.clear();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Simulator Sepak Bola')),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              itemCount: _output.length,
              itemBuilder: (context, i) => Text(_output[i]),
            ),
          ),
          TextField(
            controller: _controller,
            decoration: InputDecoration(
              hintText: 'Ketik perintah di sini...',
              border: OutlineInputBorder(),
            ),
            onSubmitted: _processCommand,
          ),
        ],
      ),
    );
  }
}
