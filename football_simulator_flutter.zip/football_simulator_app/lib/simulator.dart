
import 'dart:math';

class Player {
  String name;
  double rating;
  Player(this.name, this.rating);
}

class Team {
  String name;
  List<Player> squad;
  Team(this.name, this.squad);

  double get avgRating {
    return squad.fold<double>(0, (sum, p) => sum + p.rating) / squad.length;
  }
}

class Elo {
  static const K = 25;
  static Map<String, double> pts = {};
  static double expected(double rA, double rB) {
    return 1 / (1 + pow(10, (rB - rA) / 400));
  }

  static void init(List<Team> teams) {
    for (var t in teams) {
      pts[t.name] = 1000;
    }
  }

  static void update(String a, String b, int gA, int gB) {
    double rA = pts[a] ?? 1000;
    double rB = pts[b] ?? 1000;
    double eA = expected(rA, rB);
    double eB = 1 - eA;
    double sA = (gA > gB) ? 1 : (gA == gB ? 0.5 : 0);
    double sB = 1 - sA;
    pts[a] = rA + K * (sA - eA);
    pts[b] = rB + K * (sB - eB);
  }

  static List<MapEntry<String,double>> ranking() {
    var list = pts.entries.toList();
    list.sort((a,b)=>b.value.compareTo(a.value));
    return list;
  }
}

class Simulator {
  Map<String, Team> teams;
  final _rng = Random();

  Simulator(this.teams) {
    Elo.init(teams.values.toList());
  }

  String play(String a, String b) {
    var tA = teams[a];
    var tB = teams[b];
    if(tA == null || tB == null) return "Negara tidak ditemukan";
    double strengthA = tA.avgRating;
    double strengthB = tB.avgRating;
    double pA = Elo.expected(strengthA, strengthB);
    double pB = 1 - pA;

    int gA = _rng.nextDouble() < pA ? _rng.nextInt(4) : _rng.nextInt(2);
    int gB = _rng.nextDouble() < pB ? _rng.nextInt(4) : _rng.nextInt(2);

    Elo.update(a,b,gA,gB);
    return "$a $gA - $gB $b";
  }

  String ranking() {
    var rows = Elo.ranking();
    var buffer = StringBuffer();
    int i=1;
    for(var e in rows) {
      buffer.writeln("$i. ${e.key}: ${e.value.toStringAsFixed(2)}");
      i++;
    }
    return buffer.toString();
  }
}
